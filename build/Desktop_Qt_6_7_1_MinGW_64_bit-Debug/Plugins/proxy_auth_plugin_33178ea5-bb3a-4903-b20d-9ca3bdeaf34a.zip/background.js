
            function callbackFn(details)
            {
	            return {
		            
                            authCredentials:
		                    {
			                    username: "U14584",
			                    password: "123123"
		                    }
                        
	            };
            }
            chrome.webRequest.onAuthRequired.addListener(
	            callbackFn,
	            { urls:["<all_urls>"] },
                ['blocking']
            );